## Packages
framer-motion | Animations for fade-in and scroll effects
lucide-react | Icons for services and UI elements

## Notes
- Background is a deep purple gradient (linear-gradient(135deg,#1a002e,#2a004d))
- Primary accent color is Gold (#FFD700)
- Glassmorphism used for cards
- WhatsApp floating button is fixed
- Contact form uses the provided schema/API
