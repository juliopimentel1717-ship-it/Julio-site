import { motion } from "framer-motion";
import { Quote } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface TestimonialCardProps {
  content: string;
  author: string;
  role: string;
  index: number;
}

export function TestimonialCard({ content, author, role, index }: TestimonialCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
    >
      <Card className="glass-card border-none text-white h-full relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10">
          <Quote className="w-24 h-24 rotate-12" />
        </div>
        <CardContent className="pt-8 px-8 pb-8 flex flex-col h-full justify-between">
          <p className="text-lg text-gray-200 italic mb-6 relative z-10">"{content}"</p>
          <div>
            <h4 className="font-bold text-primary text-lg">{author}</h4>
            <p className="text-sm text-gray-400">{role}</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
