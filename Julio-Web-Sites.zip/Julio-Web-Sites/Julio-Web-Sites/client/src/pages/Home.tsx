import { motion } from "framer-motion";
import { 
  Monitor, 
  Rocket, 
  Clock, 
  Smartphone, 
  Wallet, 
  MessageCircle,
  ChevronDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/Section";
import { ServiceCard } from "@/components/ServiceCard";
import { TestimonialCard } from "@/components/TestimonialCard";
import { ContactForm } from "@/components/ContactForm";
import profileImage from "@assets/file_00000000749071f5ade0675460cd0884_1771297952113.png";

export default function Home() {
  const whatsappUrl = "https://wa.me/5543996479254";

  return (
    <div className="min-h-screen text-white overflow-hidden">
      {/* Background Decor */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-600/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary/10 rounded-full blur-[120px]" />
      </div>

      {/* Hero Section */}
      <header className="relative min-h-[90vh] flex flex-col items-center justify-center text-center px-4 pt-20 pb-32">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative z-10"
        >
          <motion.h1 
            className="text-[80px] md:text-[120px] font-bold text-primary tracking-[0.05em] leading-none mb-2 text-glow"
            initial={{ y: 20 }}
            animate={{ y: 0 }}
            transition={{ delay: 0.2 }}
          >
            JWS
          </motion.h1>
          <motion.h2 
            className="text-2xl md:text-4xl font-light text-white/90 tracking-widest mb-8"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            JULIO WEB SITES
          </motion.h2>
          <motion.p 
            className="text-lg md:text-2xl text-gray-300 max-w-2xl mx-auto mb-12 font-light"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            Transformando suas ideias em autoridade digital.
          </motion.p>
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            <Button 
              size="lg" 
              className="bg-primary text-black font-bold text-lg px-8 py-6 rounded-full hover:bg-white hover:scale-105 transition-all duration-300 shadow-[0_0_20px_rgba(255,215,0,0.3)]"
              onClick={() => window.open(whatsappUrl, "_blank")}
            >
              Solicitar Orçamento
            </Button>
          </motion.div>
        </motion.div>

        <motion.div 
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/30 animate-bounce"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
        >
          <ChevronDown className="w-10 h-10" />
        </motion.div>
      </header>

      {/* Services Section */}
      <Section className="relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Serviços</h2>
          <div className="w-24 h-1 bg-primary mx-auto rounded-full" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <ServiceCard 
            index={0}
            title="Criação de Sites Profissionais"
            description="Sites modernos, rápidos e responsivos que elevam sua autoridade digital. Otimizados para SEO e performance."
            icon={Monitor}
          />
          <ServiceCard 
            index={1}
            title="Landing Pages Estratégicas"
            description="Páginas focadas em conversão para gerar mais clientes e vendas. Design persuasivo e call-to-actions claros."
            icon={Rocket}
          />
        </div>
      </Section>

      {/* About Section */}
      <Section className="relative z-10">
        <div className="glass-card p-8 md:p-12 rounded-3xl flex flex-col md:flex-row items-center gap-12 max-w-5xl mx-auto">
          <div className="flex-1 text-center md:text-left">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Sobre Mim</h2>
            <p className="text-gray-300 text-lg leading-relaxed mb-6">
              Olá, meu nome é <strong className="text-primary">Julio Cesar Pimentel da Silva</strong>. 
              Sou fundador da JWS - Julio Web Sites e ajudo empresas a conquistarem presença digital forte, profissional e estratégica.
            </p>
            <p className="text-gray-300 text-lg leading-relaxed">
              Minha missão é entregar soluções que não apenas pareçam bonitas, mas que tragam resultados reais para o seu negócio.
            </p>
          </div>
          <motion.div 
            className="relative"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.3 }}
          >
            <div className="w-48 h-48 md:w-64 md:h-64 rounded-full border-4 border-primary overflow-hidden shadow-[0_0_30px_rgba(255,215,0,0.2)]">
              <img 
                src={profileImage} 
                alt="Foto de Julio Cesar" 
                className="w-full h-full object-cover"
              />
            </div>
            {/* HTML Comment for stock image replacement */}
            {/* <!-- Replace the src above with your actual photo URL --> */}
          </motion.div>
        </div>
      </Section>

      {/* FAQ Section */}
      <Section className="relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Dúvidas Frequentes</h2>
          <div className="w-24 h-1 bg-primary mx-auto rounded-full" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <ServiceCard 
            index={0}
            title="Tempo de Entrega"
            description="Entre 3 a 7 dias dependendo da complexidade do projeto. Priorizamos agilidade sem perder a qualidade."
            icon={Clock}
          />
          <ServiceCard 
            index={1}
            title="Responsividade"
            description="Sim! Todos os sites são 100% responsivos e funcionam perfeitamente em celulares, tablets e computadores."
            icon={Smartphone}
          />
          <ServiceCard 
            index={2}
            title="Mensalidade"
            description="Somente se desejar nosso serviço de hospedagem e manutenção contínua. O site é seu."
            icon={Wallet}
          />
        </div>
      </Section>

      {/* Testimonials */}
      <Section className="relative z-10 bg-black/20 rounded-[3rem] my-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">O Que Dizem Nossos Clientes</h2>
          <div className="w-24 h-1 bg-primary mx-auto rounded-full" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <TestimonialCard 
            index={0}
            content="O site ficou extremamente profissional. Em poucos dias já comecei a receber mais contatos pelo WhatsApp."
            author="Marcos Silva"
            role="Dono de Loja Online"
          />
          <TestimonialCard 
            index={1}
            content="A JWS entregou exatamente o que eu precisava. Atendimento rápido e resultado acima do esperado."
            author="Ana Oliveira"
            role="Consultora Financeira"
          />
          <TestimonialCard 
            index={2}
            content="Meu negócio ganhou muito mais credibilidade depois do site. Recomendo demais."
            author="Ricardo Mendes"
            role="Empreendedor Local"
          />
        </div>
      </Section>

      {/* Contact Section */}
      <Section className="relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h2 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Vamos levar seu negócio para o <span className="text-primary">próximo nível?</span>
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Entre em contato agora mesmo e peça um orçamento sem compromisso.
            </p>
            <Button 
              size="lg" 
              className="bg-[#25D366] hover:bg-[#128C7E] text-white font-bold text-lg px-8 py-6 rounded-full shadow-lg hover:scale-105 transition-all duration-300"
              onClick={() => window.open(whatsappUrl, "_blank")}
            >
              <MessageCircle className="mr-2 h-6 w-6" />
              Chamar no WhatsApp
            </Button>
          </div>
          <ContactForm />
        </div>
      </Section>

      {/* Footer */}
      <footer className="bg-[#0d0018] py-12 text-center text-gray-400 border-t border-white/5 relative z-10">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-2xl font-bold text-primary mb-4">JWS</h2>
          <p className="mb-8 max-w-md mx-auto">Transformando suas ideias em autoridade digital.</p>
          <p>© 2026 JWS - Julio Web Sites. Todos os direitos reservados.</p>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <motion.a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white px-6 py-3 rounded-full font-bold shadow-lg flex items-center gap-2 hover:bg-[#128C7E] transition-colors"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <MessageCircle className="w-6 h-6" />
        WhatsApp
      </motion.a>
    </div>
  );
}
